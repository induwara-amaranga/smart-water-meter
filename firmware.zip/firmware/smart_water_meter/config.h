// ==========================================
// Per-device settings. Each meter gets its own copy of this file.
// Keep it out of version control: it holds the Wi-Fi password and the
// meter's secret. config.example.h is the template to copy.
// ==========================================
#pragma once

// Wi-Fi
#define WIFI_SSID      "induwara"
#define WIFI_PASSWORD  "12345679"

// Meter identity: from the water board's registration slip.
// SWM-000789 is a demo meter in the backend's seed data (no account yet,
// claim code ABCD-1234 in the app).
#define METER_ID       "SWM-000789"
#define DEVICE_SECRET  "demo-secret-789"

// MQTT broker.
// Local testing: the LAN IP of the PC running `npm run dev` in backend/, port 1883, no TLS.
// Production:   your broker hostname (e.g. "mqtt.yourdomain.lk"), port 8883, TLS on.
#define MQTT_HOST      "10.227.86.167"
#define MQTT_PORT      1883
#define MQTT_USE_TLS   0

// Root CA that signed the broker's certificate (only used when MQTT_USE_TLS is 1).
// For Let's Encrypt this is "ISRG Root X1".
static const char MQTT_CA_CERT[] = R"PEM(
-----BEGIN CERTIFICATE-----
paste the CA certificate here
-----END CERTIFICATE-----
)PEM";
